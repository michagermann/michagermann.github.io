This repository includes all data and statistical code necessary to reproduce the statistical analyses reported in:

Germann, Micha, Fernando Mendez, Jonathan Wheatley, Constantinos Djouvas, Roula Nezi, and Matthew Wall. "Improving Issue Representation with Candidate-Level Voting Advice Applications", forthcoming in the European Journal of Political Research.

All analyses were conducted in Stata v18.0. The following do-files replicate all analyses reported in the paper and the online appendix, respectively:

- Paper.do
- Appendix.do

All other do-files are supplemental and are called upon in the two main do-files to create marginal effects plots.

The repository includes three data files:
- WLS_Exp.dta: The main data file.
- WLS_Complete.dta: In addition includes VAA users that were not exposed to the experimental conditions analyzed in the paper.
- Candidate_Party_Positions.dta: Includes the policy positions of parties and individual candidates on the 28 policy issues in MyVoteChoice.



MG, 24 March 2025