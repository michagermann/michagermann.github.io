Readme


This folder contains the files necessary to replicate the results in �Getting out the vote with Voting Advice Applications� (M. Germann and K. Gemenis), forthcoming in Political Communication.

Description of files:

selects07.do contains the code necessary to replicate all of the analyses based on the 2007 Swiss election study. Stata is needed to reproduce the results. Note that selects07.do calls on several ancillary do-files stored in the �Extra do-files� folder.

selects11.do/selects15.do contain the code necessary to reproduce the analysis based on the 2011/2015 Swiss election studies.

All data files called upon by the do-files, figures produced, and log files of the Stata output can be found in the respective folders.

MG

June 5, 2018




