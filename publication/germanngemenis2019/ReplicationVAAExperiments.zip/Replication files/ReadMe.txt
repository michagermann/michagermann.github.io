This repository includes all data files which are necessary to reproduce the statistical analyses reported in:

Germann, Micha, Fernando Mendez, and Kostas Gemenis. "Do voting advice applications affect party preferences? Evidence from field experiments in five European countries", forthcoming in Political Communication.

More specifically:

BG_EP.csv includes all data from the experiment in Bulgaria.
ESP_EP.csv includes all data from the experiment in Spain.
GR_EP.csv includes all data from the experiment in Greece.
RO_EP.csv includes all data from the experiment in Romania.
UK_EP.csv includes all data from the experiment in the UK (European elections).
UK_GE.csv includes all data from the experiment in the UK (general election).

Also included is the code necessary to reproduce all tables and figures reported in Stata. We used Stata v17.0 for all analyses.

Analysis_Manuscript.do reproduces all analyses reported in the manuscript itself.
Analysis_Supplement.do reproduces all analyses reported in the Online Supplemental Material.

All remaining .do files are supplemental. They reproduce different figures and are called upon in the two main .do files.

MG, 12 January 2023