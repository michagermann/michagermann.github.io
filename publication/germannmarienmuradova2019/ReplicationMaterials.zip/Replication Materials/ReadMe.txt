This repository includes the data and statistical code necessary to replicate all analyses reported in:

Germann, Micha, Sofie Marien, and Lala Muradova. "Scaling Up? Unpacking the Effect of Deliberative Mini-Publics on Legitimacy Perceptions." Political Studies, forthcoming.


DataFinal.dta includes the data.

Manuscript.do replicates all analyses reported in the paper.

Additional analyses reported in the Supplemental Material can be replicated using these files:
- Supp_SampleDescriptives: Table S1
- Supp_Scaling: Tables S2 & S3
- Supp_SubGroup: Tables S4-S6
- Supp_RobustnessCovariates: Tables S7-S10 & Figure S1
- Supp_RobustnessThresholds: Tables S11-S14 & Figures S2-S3
- Supp_RobustnessHeardOfCA: Table S15
- Supp_RobustnessCompliers: Table S16
- Supp_RobustnessFullSample: Tables S17-S20 & Figure S4
- Supp_RobustnessOpinionChange: Table S21


All analyses were conducted in Stata 17.