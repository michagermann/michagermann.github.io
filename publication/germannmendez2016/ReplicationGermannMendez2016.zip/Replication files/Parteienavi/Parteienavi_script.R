
#  	########################################################################		#
#		########################################################################		#
#		  File:				    Parteienavi_script.R                        							#
#		  Date:			  	  October 2014								                        			#
#		  Author:			    MG												                            		#
#		  Purpose:			  Dynamic Scale Validation Reloaded   			            		#
#		  Input file:		  Several     									                        		#         
#		  Log file:			  Rlog_Parteienavi.txt							                    		#
#		  Data output:	  None										                          		  	#
#		  Machine:		  	Office laptop							                        				#
#		  R version:	    3.1.0										                          				#
#		########################################################################		#
#		########################################################################		#



##################################################################################
## Install & load packages, set memory size, set working directory, start log file
##################################################################################

install.packages("mokken")
install.packages("poLCA")
install.packages("polycor")
install.packages("psych")
install.packages("GPArotation")
install.packages("nFactors")
install.packages("lavaan")
install.packages("semTools")
install.packages("TeachingDemos")

library(mokken)
library(poLCA)
library(polycor)
library(psych)
library(GPArotation)
library(nFactors)
library(lavaan)
library(semTools)
require(TeachingDemos)

memory.size(max=TRUE)

# Set directory
setwd(".../Replication files/Parteienavi")

txtStart(file="Rlog_Parteienavi.txt")  # Start recording to Rlog_Parteienavi.txt



###########
## Table 1a
###########


# Check ex-ante scales


# Mokken scaling analysis
first3000exante.data <- read.table("Parteienavi_exante_first3000.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(first3000exante.data)
first3000_exante_LR.data <- data.frame(cbind( q2_rev, q8_rev, q9, q10_rev, q11_rev, q12_rev, q14_rev, q15_rev, q16_rev, q17, q18, q20_rev, q24))
first3000_exante_Cult.data <- data.frame(cbind( q1_rev, q5, q19, q22, q25, q26_rev, q27, q29_rev, q30))
detach(first3000exante.data)
coefH(first3000_exante_LR.data)
m.first3000_exante_LR <- check.monotonicity(first3000_exante_LR.data, minsize = 100)
summary(m.first3000_exante_LR)
coefH(first3000_exante_Cult.data)
m.first3000_exante_Cult <- check.monotonicity(first3000_exante_Cult.data, minsize = 100)
summary(m.first3000_exante_Cult)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
cfa.exante <-   'LR =~ q2_rev + q8_rev + q9 + q10_rev + q11_rev + q12_rev + q14_rev + q15_rev + q16_rev + q17 + q18 + q20_rev + q24
                Cult =~ q1_rev + q5 + q19 + q22 + q25 + q26_rev + q27 + q29_rev + q30'
cfa.exante.fit <- cfa(cfa.exante, data=first3000exante.data, std.lv=T, ordered=c("q2_rev", "q8_rev", "q9", "q10_rev", "q11_rev", "q12_rev", "q14_rev", "q15_rev", "q16_rev", "q17", "q18", "q20_rev", "q24", "q1_rev", "q5", "q19", "q22", "q25", "q26_rev", "q27", "q29_rev", "q30" ))
reliability(cfa.exante.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
first3000exantepoLCA.data <- read.table("Parteienavi_exante_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(first3000exantepoLCA.data)
poLCA_exante_LR <- data.frame(cbind( q2_rev_poLCA, q8_rev_poLCA, q9_poLCA, q10_rev_poLCA, q11_rev_poLCA, q12_rev_poLCA, q14_rev_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q24_poLCA))
poLCA_exante_Cult <- data.frame(cbind( q1_rev_poLCA, q5_poLCA, q19_poLCA, q22_poLCA, q25_poLCA, q26_rev_poLCA, q27_poLCA, q29_rev_poLCA, q30_poLCA))
detach(first3000exantepoLCA.data)

# Estimate number of latent classes
# LR
f <- cbind( q2_rev_poLCA, q8_rev_poLCA, q9_poLCA, q10_rev_poLCA, q11_rev_poLCA, q12_rev_poLCA, q14_rev_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q24_poLCA)~1
poLCA(f,poLCA_exante_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q1_rev_poLCA, q5_poLCA, q19_poLCA, q22_poLCA, q25_poLCA, q26_rev_poLCA, q27_poLCA, q29_rev_poLCA, q30_poLCA)~1
poLCA(f,poLCA_exante_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 4, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(first3000_exante_LR.data, LCRC=T, nclass=4)
check.reliability (first3000_exante_Cult.data, LCRC=T, nclass=3)


###############################################################################################################################



###########
## Table A1
###########


# Quasi-inductive search using AISP algorithm
# Items 10 & 19 are excluded b/c they cross-load (see below)
emok28.data <- read.table("Parteienavi_emok28.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Run AISP
aisp <- aisp(emok28.data, search = "normal", lowerbound = .3)
coefH(emok28.data[,aisp ==1])
coefH(emok28.data[,aisp ==2])
coefH(emok28.data[,aisp ==3])
coefH(emok28.data[,aisp ==4])
coefH(emok28.data[,aisp ==5])

# Monotonicity test of two resulting scales
attach(emok28.data)
cmok.LR.aisp  <- data.frame(cbind( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev))
cmok.Cult.aisp <- data.frame(cbind( q7_rev, q13_rev, q22, q27, q30))
detach(emok28.data)
coefH(cmok.LR.aisp)
m.cmok.LR.aisp <- check.monotonicity(cmok.LR.aisp, minsize = 100)
summary(m.cmok.LR.aisp)
coefH(cmok.Cult.aisp)
m.cmok.Cult.aisp <- check.monotonicity(cmok.Cult.aisp, minsize = 100)
summary(m.cmok.Cult.aisp)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
attach(emok28.data)
cfa.aisp.data <- data.frame(cbind( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q7_rev, q13_rev, q22, q27, q30))
detach(emok28.data)
cfa.aisp <-   'LR =~ q5_rev + q11_rev + q14_rev + q16_rev + q17 + q18 + q20_rev + q23_rev
              Cult =~ q7_rev + q13_rev + q22 + q27 + q30'
cfa.aisp.fit <- cfa(cfa.aisp, data=cfa.aisp.data, std.lv=T, ordered=c( "q5_rev", "q11_rev", "q14_rev", "q16_rev", "q17", "q18", "q20_rev", "q23_rev", "q7_rev", "q13_rev", "q22", "q27", "q30"))
reliability(cfa.aisp.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
poLCA.aisp <- read.table("Parteienavi_28_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(poLCA.aisp)
poLCA_aisp_LR <- data.frame(cbind( q5_rev_poLCA, q11_rev_poLCA, q14_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q23_rev_poLCA))
poLCA_aisp_Cult <- data.frame(cbind( q7_rev_poLCA, q13_rev_poLCA, q22_poLCA, q27_poLCA, q30_poLCA))
detach(poLCA.aisp)

# Estimate number of latent classes
# LR
f <- cbind( q5_rev_poLCA, q11_rev_poLCA, q14_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q23_rev_poLCA)~1
poLCA(f,poLCA_aisp_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind( q7_rev_poLCA, q13_rev_poLCA, q22_poLCA, q27_poLCA, q30_poLCA)~1
poLCA(f,poLCA_aisp_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 4, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(cmok.LR.aisp, LCRC=T, nclass=4)
check.reliability (cmok.Cult.aisp, LCRC=T, nclass=3)


###############################################################################################################################



###########
## Table 1b
###########


# Quasi-inductive search using GA algorithm
# Items 10 & 19 are excluded b/c they cross-load (see below)

# Run GA
ga <- aisp(emok28.data, search = "ga", lowerbound = .3)
coefH(emok28.data[,ga ==1])
coefH(emok28.data[,ga ==2])
coefH(emok28.data[,ga ==3])
coefH(emok28.data[,ga ==4])
coefH(emok28.data[,ga ==5])
coefH(emok28.data[,ga ==6])

# GA algorithm outputs two variants of LR (either with item 5 or with item 8)
# Item 8 (subsidies for organic farming) seems to fit LR better than item 5 (integrated schools)
# GA algorith outputs two variants of the cultural scale (either with item 13 or with item 27)
# Item 27 (gay adoption right) seeems to fit cultural scale better than item 13 (fuel tax)

# Monotonicity test of two resulting scales
attach(emok28.data)
cmok.LR.ga  <- data.frame(cbind( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev))
cmok.Cult.ga <- data.frame(cbind( q6, q7_rev, q22, q27, q30))
detach(emok28.data)
coefH(cmok.LR.ga)
m.cmok.LR.ga <- check.monotonicity(cmok.LR.ga, minsize = 100)
summary(m.cmok.LR.ga)
coefH(cmok.Cult.ga)
m.cmok.Cult.ga <- check.monotonicity(cmok.Cult.ga, minsize = 100)
summary(m.cmok.Cult.ga)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
attach(emok28.data)
cfa.ga.data <- data.frame(cbind( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q6, q7_rev, q22, q27, q30))
detach(emok28.data)
cfa.ga <-   'LR =~ q8_rev + q11_rev + q14_rev + q16_rev + q17 + q18 + q20_rev + q23_rev
            Cult =~ q6 + q7_rev + q22 + q27 + q30'
cfa.ga.fit <- cfa(cfa.ga, data=cfa.ga.data, std.lv=T, ordered=c( "q8_rev", "q11_rev", "q14_rev", "q16_rev", "q17", "q18", "q20_rev", "q23_rev", "q6", "q7_rev", "q22", "q27", "q30"))
reliability(cfa.ga.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
poLCA.ga <- read.table("Parteienavi_28_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(poLCA.ga)
poLCA_ga_LR <- data.frame(cbind( q8_rev_poLCA, q11_rev_poLCA, q14_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q23_rev_poLCA))
poLCA_ga_Cult <- data.frame(cbind( q6_poLCA, q7_rev_poLCA, q22_poLCA, q27_poLCA, q30_poLCA))
detach(poLCA.ga)

# Estimate number of latent classes
# LR
f <- cbind( q8_rev_poLCA, q11_rev_poLCA, q14_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q23_rev_poLCA)~1
poLCA(f,poLCA_ga_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind( q6_poLCA, q7_rev_poLCA, q22_poLCA, q27_poLCA, q30_poLCA)~1
poLCA(f,poLCA_ga_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 5, maxiter = 5000,nrep=5)

# Reliability coefficients
check.reliability(cmok.LR.ga, LCRC=T, nclass=4)
check.reliability (cmok.Cult.ga, LCRC=T, nclass=4)


###############################################################################################################################



# Ambiguity check (AISP solution)
# Show that there are no cross-loadings
lr1 <- subset(emok28.data, select=c( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q7))
lr2 <- subset(emok28.data, select=c( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q13))
lr3 <- subset(emok28.data, select=c( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q22_rev))
lr4 <- subset(emok28.data, select=c( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q27_rev))
lr5 <- subset(emok28.data, select=c( q5_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q30_rev))
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)

cult1 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q5))       
cult2 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q11))
cult3 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q14))       
cult4 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q16))               
cult5 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q17_rev))       
cult6 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q18_rev))
cult7 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q20))        
cult8 <- subset(emok28.data, select=c(q7_rev, q13_rev, q22, q27, q30, q23))                                                
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)              


# Ambiguity check (GA solution)
# Show that there are no cross-loadings
lr1 <- subset(emok28.data, select=c( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q6_rev))
lr2 <- subset(emok28.data, select=c( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q7))
lr3 <- subset(emok28.data, select=c( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q22_rev))
lr4 <- subset(emok28.data, select=c( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q27_rev))
lr5 <- subset(emok28.data, select=c( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev, q30_rev))
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)


cult1 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q8 ))
cult2 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q11 ))
cult3 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q14 ))
cult4 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q16 ))
cult5 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q17_rev ))
cult6 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q18_rev ))
cult7 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q20 ))
cult8 <- subset(emok28.data, select=c(q6, q7_rev, q22, q27, q30, q23 ))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)


###############################################################################################################################


# Quasi-inductive searches using all 30 items
# Show that items 10 & 19 cross-load

# AISP algorithm
emok.data <- read.table("Parteienavi_emok.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

aisp <- aisp(emok.data, search = "normal", lowerbound = .3)
coefH(emok.data[,aisp ==1])
coefH(emok.data[,aisp ==2])
coefH(emok.data[,aisp ==3])
coefH(emok.data[,aisp ==4])
coefH(emok.data[,aisp ==5])

# Ambiguity check
lr1 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q6_rev))
lr2 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q7))
lr3 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q13))
lr4 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q22_rev))
lr5 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q27_rev))
lr6 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q30_rev))
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)
coefH(lr6)

cult1 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q5))
cult2 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q8 ))
cult3 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q10 ))
cult4 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q11 ))
cult5 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q14 ))
cult6 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q16 ))
cult7 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q17_rev ))
cult8 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q18_rev ))
cult9 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q19 ))
cult10 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q20 ))
cult11 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q27, q30, q23 ))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)
coefH(cult9)
coefH(cult10)
coefH(cult11)

# item 10 fits both scales, and item 19 almost (Hi=.298 on lr)


# GA algorithm
ga <- aisp(emok.data, search = "ga", lowerbound = .3)
coefH(emok.data[,ga ==1])
coefH(emok.data[,ga ==2])
coefH(emok.data[,ga ==3])
coefH(emok.data[,ga ==4])
coefH(emok.data[,ga ==5])
coefH(emok.data[,ga ==6])


# Ambiguity check 
# Two variants of a cultural scale come out...both are tested
lr1 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q6_rev))
lr2 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q7))
lr3 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q13))
lr4 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q22_rev))
lr5 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q27_rev))
lr6 <- subset(emok.data, select=c( q5_rev, q8_rev, q10_rev, q11_rev, q14_rev, q16_rev, q17, q18, q19_rev, q20_rev, q23_rev, q30_rev))
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)
coefH(lr6)

cult1 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q5))
cult2 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q8 ))
cult3 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q10 ))
cult4 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q11 ))
cult5 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q14 ))
cult6 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q16 ))
cult7 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q17_rev ))
cult8 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q18_rev ))
cult9 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q19 ))
cult10 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q20 ))
cult11 <- subset(emok.data, select=c(q7_rev, q13_rev, q22, q27, q30, q23 ))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)
coefH(cult9)
coefH(cult10)
coefH(cult11)

cult1 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q5))
cult2 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q8 ))
cult3 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q10 ))
cult4 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q11 ))
cult5 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q14 ))
cult6 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q16 ))
cult7 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q17_rev ))
cult8 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q18_rev ))
cult9 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q19 ))
cult10 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q20 ))
cult11 <- subset(emok.data, select=c(q6, q7_rev, q13_rev, q22, q30, q23 ))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)
coefH(cult9)
coefH(cult10)
coefH(cult11)

# Item 10 always cross-loads; item 19 on the first version of cultural scale loads with Hi = .296, and second with Hi = .273


###############################################################################################################################



# Confirm 2-D structure using EFA (polychoric principal axis)

efa.data <- read.table("Parteienavi_efa.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Determine number of factors
pa.poly <- fa.poly(x=efa.data, fm="pa", nfactors=2, rotate="promax")
pa.poly$fa$values
plot(pa.poly$fa$values,type="b", main = "Scree plot",ylab="Eigenvalues of factors",ylim=c(0,max(pa.poly$fa$values)) ,xlab="Factor Number",pch=4,col="blue")

# Two-factor solution, promax-rotated (to be preferred if there are items with strong crossloadings, see Thompson 2004)
print(pa.poly$fa, digits=3, cut=.3)


#########################################################################################################



###########
## Table 4a
###########


# Check ex-ante scales

# Mokken scaling analysis
lateexante.data <- read.table("Parteienavi_exante_late.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateexante.data)
late_exante_LR.data <- data.frame(cbind( q2_rev, q8_rev, q9, q10_rev, q11_rev, q12_rev, q14_rev, q15_rev, q16_rev, q17, q18, q20_rev, q24))
late_exante_Cult.data <- data.frame(cbind( q1_rev, q5, q19, q22, q25, q26_rev, q27, q29_rev, q30))
detach(lateexante.data)
coefH(late_exante_LR.data)
m.late_exante_LR <- check.monotonicity(late_exante_LR.data, minsize = 100)
summary(m.late_exante_LR)
coefH(late_exante_Cult.data)
m.late_exante_Cult <- check.monotonicity(late_exante_Cult.data, minsize = 100)
summary(m.late_exante_Cult)

# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS)
cfa.exante <-   'LR =~ q2_rev + q8_rev + q9 + q10_rev + q11_rev + q12_rev + q14_rev + q15_rev + q16_rev + q17 + q18 + q20_rev + q24
Cult =~ q1_rev + q5 + q19 + q22 + q25 + q26_rev + q27 + q29_rev + q30'
cfa.exante.fit <- cfa(cfa.exante, data=lateexante.data, std.lv=T, ordered=c("q2_rev", "q8_rev", "q9", "q10_rev", "q11_rev", "q12_rev", "q14_rev", "q15_rev", "q16_rev", "q17", "q18", "q20_rev", "q24", "q1_rev", "q5", "q19", "q22", "q25", "q26_rev", "q27", "q29_rev", "q30"))
reliability(cfa.exante.fit)


# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC

# Estimate number of latent classes
lateexantepoLCA.data <- read.table("Parteienavi_exante_late_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateexantepoLCA.data)
poLCA_exante_LR <- data.frame(cbind( q2_rev_poLCA, q8_rev_poLCA, q9_poLCA, q10_rev_poLCA, q11_rev_poLCA, q12_rev_poLCA, q14_rev_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q24_poLCA))
poLCA_exante_Cult <- data.frame(cbind( q1_rev_poLCA, q5_poLCA, q19_poLCA, q22_poLCA, q25_poLCA, q26_rev_poLCA, q27_poLCA, q29_rev_poLCA, q30_poLCA))
detach(lateexantepoLCA.data)

# LR
f <- cbind( q2_rev_poLCA, q8_rev_poLCA, q9_poLCA, q10_rev_poLCA, q11_rev_poLCA, q12_rev_poLCA, q14_rev_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q24_poLCA)~1
poLCA(f,poLCA_exante_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 13, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 14, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 15, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 16, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 17, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 18, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 19, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 20, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 21, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 22, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 23, maxiter = 5000,nrep=5)
# Cult
f <- cbind( q1_rev_poLCA, q5_poLCA, q19_poLCA, q22_poLCA, q25_poLCA, q26_rev_poLCA, q27_poLCA, q29_rev_poLCA, q30_poLCA)~1
poLCA(f,poLCA_exante_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 13, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 14, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 15, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 16, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 17, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 18, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 19, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(late_exante_LR.data, LCRC=T, nclass=22)
check.reliability (late_exante_Cult.data, LCRC=T, nclass=18)


###############################################################################################################################



###########
## Table 4b
###########


# Check quasi-inductive scales


# Mokken scaling analysis
lateqi.data <- read.table("Parteienavi_qi_late.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateqi.data)
late_qi_LR.data <- data.frame(cbind( q8_rev, q11_rev, q14_rev, q16_rev, q17, q18, q20_rev, q23_rev))
late_qi_Cult.data <- data.frame(cbind( q6, q7_rev, q22, q27, q30))
detach(lateqi.data)
coefH(late_qi_LR.data)
m.late_qi_LR <- check.monotonicity(late_qi_LR.data, minsize = 100)
summary(m.late_qi_LR)
coefH(late_qi_Cult.data)
m.late_qi_Cult <- check.monotonicity(late_qi_Cult.data, minsize = 100)
summary(m.late_qi_Cult)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS)
cfa.qi <-   'LR =~ q8_rev + q11_rev + q14_rev + q16_rev + q17 + q18 + q20_rev + q23_rev
Cult =~ q6 + q7_rev + q22 + q27 + q30'
cfa.qi.fit <- cfa(cfa.qi, data=lateqi.data, std.lv=T, ordered=c( "q8_rev", "q11_rev", "q14_rev", "q16_rev", "q17", "q18", "q20_rev", "q23_rev", "q6", "q7_rev", "q22", "q27", "q30"))
reliability(cfa.qi.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC

# Estimate number of latent classes
lateqipoLCA.data <- read.table("Parteienavi_qi_late_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateqipoLCA.data)
poLCA_qi_LR <- data.frame(cbind( q8_rev_poLCA, q11_rev_poLCA, q14_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q23_rev_poLCA))
poLCA_qi_Cult <- data.frame(cbind( q6_poLCA, q7_rev_poLCA, q22_poLCA, q27_poLCA, q30_poLCA))
detach(lateqipoLCA.data)

# LR
f <- cbind( q8_rev_poLCA, q11_rev_poLCA, q14_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q20_rev_poLCA, q23_rev_poLCA)~1
poLCA(f,poLCA_qi_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 13, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 14, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 15, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 16, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q6_poLCA, q7_rev_poLCA, q22_poLCA, q27_poLCA, q30_poLCA)~1
poLCA(f,poLCA_qi_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 10, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(late_qi_LR.data, LCRC=T, nclass=15)
check.reliability (late_qi_Cult.data, LCRC=T, nclass=9)


txtStop()  # Stop recording
