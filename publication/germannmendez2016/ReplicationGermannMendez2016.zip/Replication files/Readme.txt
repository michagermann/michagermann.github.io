Readme

October 2014

Replication code for:

�Dynamic Scale Validation Reloaded�

Both R and Stata were used for the statistical analyses. In particular, R was used for the scaling analyses in Tables 1-6 and Stata for the assessment of the implications of dynamic scale validation (Tables 7-9 & Figure 4). 

The data input for R (.csv files) was exported from Stata. 

Please do not hesitate to contact us (micha.germann@zda.uzh.ch)


MG
