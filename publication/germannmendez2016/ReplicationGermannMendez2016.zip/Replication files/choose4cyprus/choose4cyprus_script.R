
#    ########################################################################  	#
#	   ########################################################################		#
#		  File:				    choose4cyprus_script.R                      							#
#		  Date:			  	  October 2014								                        			#
#		  Author:			    MG												                            		#
#		  Purpose:			  Dynamic Scale Validation Reloaded   			            		#
#		  Input file:		  Several     									                        		#         
#		  Log file:			  Rlog_choose4cyprus.txt						                    		#
#		  Data output:	  None										                          		  	#
#		  Machine:		  	Office laptop							                        				#
#		  R version:	    3.1.0										                          				#
#		########################################################################		#
#		########################################################################		#



##################################################################################
## Install & load packages, set memory size, set working directory, start log file
##################################################################################

install.packages("mokken")
install.packages("poLCA")
install.packages("polycor")
install.packages("psych")
install.packages("GPArotation")
install.packages("nFactors")
install.packages("lavaan")
install.packages("semTools")
install.packages("TeachingDemos")

library(mokken)
library(poLCA)
library(polycor)
library(psych)
library(GPArotation)
library(nFactors)
library(lavaan)
library(semTools)
require(TeachingDemos)

memory.size(max=TRUE)

# Set directory
setwd(".../Replication files/choose4cyprus")

txtStart(file="Rlog_choose4cyprus.txt")  # Start recording to Rlog_choose4cyprus.txt



###########
## Table 3a
###########


# Check ex-ante scales


# Mokken scaling analysis
first3000exante.data <- read.table("choose4cyprus_exante_first3000.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(first3000exante.data)
first3000_exante_LR.data <- data.frame(cbind( q1_rev, q2_rev, q4_rev, q5, q7, q8, q10, q11, q26, q27, q29, q30))
first3000_exante_Cult.data <- data.frame(cbind(q9_rev, q13, q14, q15_rev, q16_rev, q17_rev, q18_rev, q19_rev, q20, q21, q22, q23, q25))
detach(first3000exante.data)
coefH(first3000_exante_LR.data)
m.first3000_exante_LR <- check.monotonicity(first3000_exante_LR.data, minsize = 100)
summary(m.first3000_exante_LR)
coefH(first3000_exante_Cult.data)
m.first3000_exante_Cult <- check.monotonicity(first3000_exante_Cult.data, minsize = 100)
summary(m.first3000_exante_Cult)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
cfa.exante <-   'LR =~ q1_rev + q2_rev + q4_rev + q5 + q7 + q8 + q10 + q11 + q26 + q27 + q29 + q30
                Cult =~ q9_rev + q13 + q14 + q15_rev + q16_rev + q17_rev + q18_rev + q19_rev + q20 + q21 + q22 + q23 + q25'
cfa.exante.fit <- cfa(cfa.exante, data=first3000exante.data, std.lv=T, ordered=c("q1_rev", "q2_rev", "q4_rev", "q5", "q7", "q8", "q10", "q11", "q26", "q27", "q29", "q30", "q9_rev", "q13", "q14", "q15_rev", "q16_rev", "q17_rev", "q18_rev", "q19_rev", "q20", "q21", "q22", "q23", "q25"))
reliability(cfa.exante.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
first3000exantepoLCA.data <- read.table("choose4cyprus_exante_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(first3000exantepoLCA.data)
poLCA_exante_LR <- data.frame(cbind( q1_rev_poLCA, q2_rev_poLCA, q4_rev_poLCA, q5_poLCA, q7_poLCA, q8_poLCA, q10_poLCA, q11_poLCA, q26_poLCA, q27_poLCA, q29_poLCA, q30_poLCA))
poLCA_exante_Cult <- data.frame(cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q20_poLCA, q21_poLCA, q22_poLCA, q23_poLCA, q25_poLCA))
detach(first3000exantepoLCA.data)

# Estimate number of latent classes
# LR
f <- cbind(q1_rev_poLCA, q2_rev_poLCA, q4_rev_poLCA, q5_poLCA, q7_poLCA, q8_poLCA, q10_poLCA, q11_poLCA, q26_poLCA, q27_poLCA, q29_poLCA, q30_poLCA)~1
poLCA(f,poLCA_exante_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 6, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q20_poLCA, q21_poLCA, q22_poLCA, q23_poLCA, q25_poLCA)~1
poLCA(f,poLCA_exante_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 8, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(first3000_exante_LR.data, LCRC=T, nclass=5)
check.reliability (first3000_exante_Cult.data, LCRC=T, nclass=7)


###############################################################################################################################



###########
## Table A3
###########


# Quasi-inductive search using AISP algorithm
# Get data
emok.data <- read.table("choose4cyprus_emok.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

aisp <- aisp(emok.data, search = "normal", lowerbound = .3)
coefH(emok.data[,aisp ==1])
coefH(emok.data[,aisp ==2])
coefH(emok.data[,aisp ==3])
coefH(emok.data[,aisp ==4])
coefH(emok.data[,aisp ==5])
coefH(emok.data[,aisp ==6])
coefH(emok.data[,aisp ==7])

# Monotonicity test of two main scales
attach(emok.data)
cmok.LR.aisp  <- data.frame(cbind( q7, q8, q10, q11, q26, q29))
cmok.Cult.aisp <- data.frame(cbind(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25))
detach(emok.data)
coefH(cmok.LR.aisp)
m.cmok.LR.aisp <- check.monotonicity(cmok.LR.aisp, minsize = 100)
summary(m.cmok.LR.aisp)
coefH(cmok.Cult.aisp)
m.cmok.Cult.aisp <- check.monotonicity(cmok.Cult.aisp, minsize = 100)
summary(m.cmok.Cult.aisp)



# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
attach(emok.data)
cfa.aisp.data <- data.frame(cbind(q7, q8, q10, q11, q26, q29, q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25))
detach(emok.data)
cfa.aisp <-   'LR =~ q7 + q8 + q10 + q11 +q26 + q29
Cult =~ q9_rev + q13 + q14 + q16_rev + q17_rev + q18_rev + q19_rev + q21 + q23 + q25'
cfa.aisp.fit <- cfa(cfa.aisp, data=cfa.aisp.data, std.lv=T, ordered=c( "q7", "q8", "q10", "q11", "q26", "q29", "q9_rev", "q13", "q14", "q16_rev", "q17_rev", "q18_rev", "q19_rev", "q21", "q23", "q25"))
reliability(cfa.aisp.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
poLCA.aisp <- read.table("choose4cyprus_all_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(poLCA.aisp)
poLCA_aisp_LR <- data.frame(cbind( q7_poLCA, q8_poLCA, q10_poLCA, q11_poLCA, q26_poLCA, q29_poLCA))
poLCA_aisp_Cult <- data.frame(cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q21_poLCA, q23_poLCA, q25_poLCA))
detach(poLCA.aisp)

# Estimate number of latent classes
# LR
f <- cbind(q7_poLCA, q8_poLCA, q10_poLCA, q11_poLCA, q26_poLCA, q29_poLCA)~1
poLCA(f,poLCA_aisp_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q21_poLCA, q23_poLCA, q25_poLCA)~1
poLCA(f,poLCA_aisp_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 7, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(cmok.LR.aisp, LCRC=T, nclass=4)
check.reliability (cmok.Cult.aisp, LCRC=T, nclass=6)


###############################################################################################################################



###########
## Table 3b
###########


# Quasi-inductive search using GA algorithm

# Run GA
ga <- aisp(emok.data, search = "ga", lowerbound = .3)
coefH(emok.data[,ga ==1])
coefH(emok.data[,ga ==2])
coefH(emok.data[,ga ==3])
coefH(emok.data[,ga ==4])
coefH(emok.data[,ga ==5])
coefH(emok.data[,ga ==6])
coefH(emok.data[,ga ==7])
coefH(emok.data[,ga ==8])
coefH(emok.data[,ga ==9])

# Monotonicity test of two resulting scales
attach(emok.data)
cmok.LR.ga  <- data.frame(cbind( q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30))
cmok.Cult.ga <- data.frame(cbind( q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25))
detach(emok.data)
coefH(cmok.LR.ga)
m.cmok.LR.ga <- check.monotonicity(cmok.LR.ga, minsize = 100)
summary(m.cmok.LR.ga)
coefH(cmok.Cult.ga)
m.cmok.Cult.ga <- check.monotonicity(cmok.Cult.ga, minsize = 100)
summary(m.cmok.Cult.ga)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
attach(emok.data)
cfa.ga.data <- data.frame(cbind( q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25))
detach(emok.data)
cfa.ga <-   'LR =~ q1_rev + q4_rev + q6_rev + q7 + q11 + q26 + q29 + q30
Cult =~ q9_rev + q13 + q14 + q16_rev + q17_rev + q18_rev + q19_rev + q21 + q23 + q25'
cfa.ga.fit <- cfa(cfa.ga, data=cfa.ga.data, std.lv=T, ordered=c( "q1_rev", "q4_rev", "q6_rev", "q7", "q11", "q26", "q29", "q30", "q9_rev", "q13", "q14", "q16_rev", "q17_rev", "q18_rev", "q19_rev", "q21", "q23", "q25"))
reliability(cfa.ga.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
poLCA.ga <- read.table("choose4cyprus_all_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(poLCA.ga)
poLCA_ga_LR <- data.frame(cbind( q1_rev_poLCA, q4_rev_poLCA, q6_rev_poLCA, q7_poLCA, q11_poLCA, q26_poLCA, q29_poLCA, q30_poLCA))
poLCA_ga_Cult <- data.frame(cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q21_poLCA, q23_poLCA, q25_poLCA))
detach(poLCA.ga)

# Estimate number of latent classes
# LR
f <- cbind( q1_rev_poLCA, q4_rev_poLCA, q6_rev_poLCA, q7_poLCA, q11_poLCA, q26_poLCA, q29_poLCA, q30_poLCA)~1
poLCA(f,poLCA_ga_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 6, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q21_poLCA, q23_poLCA, q25_poLCA)~1
poLCA(f,poLCA_ga_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 7, maxiter = 5000,nrep=5)

# Reliability coefficients
check.reliability(cmok.LR.ga, LCRC=T, nclass=5)
check.reliability (cmok.Cult.ga, LCRC=T, nclass=6)


###############################################################################################################################



# Ambiguity check (AISP solution)
# Show that there are no cross-loadings
lr1 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q9))
lr2 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q13_rev))
lr3 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q14_rev))
lr4 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q16))
lr5 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q17))
lr6 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q18))
lr7 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q19))
lr8 <- subset(emok.data, select=c(q7, q8, q10, q11, q26, q29, q21_rev))
lr9 <- subset(emok.data, select=c(q7, q8, q11, q26, q29, q23_rev))
lr10 <- subset(emok.data, select=c(q7, q8, q11, q26, q29, q25_rev))              
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)
coefH(lr6)
coefH(lr7)
coefH(lr8)
coefH(lr9)
coefH(lr10)

cult1 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q7_rev))
cult2 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q8_rev))
cult3 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q11_rev))
cult4 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q26_rev))
cult5 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q29_rev))
cult6 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q10_rev))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)


# Ambiguity check (GA solution)
# Show that there are no cross-loadings
lr1 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q9))
lr2 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q13_rev))
lr3 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q14_rev))
lr4 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q16))
lr5 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q17))
lr6 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q18))
lr7 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q19))
lr8 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q21_rev))
lr9 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q23_rev))
lr10 <- subset(emok.data, select=c(q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30, q25_rev))              
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)
coefH(lr6)
coefH(lr7)
coefH(lr8)
coefH(lr9)
coefH(lr10)

cult1 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q1))
cult2 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q4))
cult3 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q6))
cult4 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q7_rev))
cult5 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q11_rev))
cult6 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q26_rev))
cult7 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q29_rev))
cult8 <- subset(emok.data, select=c(q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25, q30_rev))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)


###############################################################################################################################



# Confirm 2-D structure using EFA (polychoric principal axis)
efa.data <- read.table("choose4cyprus_efa.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Determine number of factors
pa.poly <- fa.poly(x=efa.data, fm="pa", nfactors=2, rotate="promax")
pa.poly$fa$values
plot(pa.poly$fa$values,type="b", main = "Scree plot",ylab="Eigenvalues of factors",ylim=c(0,max(pa.poly$fa$values)) ,xlab="Factor Number",pch=4,col="blue")

# Two-factor solution, promax-rotated (to be preferred if there are items with strong crossloadings, see Thompson 2004)
print(pa.poly$fa, digits=3, cut=.3)


#########################################################################################################



###########
## Table 6a
###########


# Check ex-ante scales

# Mokken scaling analysis
lateexante.data <- read.table("choose4cyprus_exante_late.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateexante.data)
late_exante_LR.data <- data.frame(cbind( q1_rev, q2_rev, q4_rev, q5, q7, q8, q10, q11, q26, q27, q29, q30))
late_exante_Cult.data <- data.frame(cbind(q9_rev, q13, q14, q15_rev, q16_rev, q17_rev, q18_rev, q19_rev, q20, q21, q22, q23, q25))
detach(lateexante.data)
coefH(late_exante_LR.data)
m.late_exante_LR <- check.monotonicity(late_exante_LR.data, minsize = 100)
summary(m.late_exante_LR)
coefH(late_exante_Cult.data)
m.late_exante_Cult <- check.monotonicity(late_exante_Cult.data, minsize = 100)
summary(m.late_exante_Cult)

# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS)
cfa.exante <-   'LR =~ q1_rev + q2_rev + q4_rev + q5 + q7 + q8 + q10 + q11 + q26 + q27 + q29 + q30
Cult =~ q9_rev + q13 + q14 + q15_rev + q16_rev + q17_rev + q18_rev + q19_rev + q20 + q21 + q22 + q23 + q25'
cfa.exante.fit <- cfa(cfa.exante, data=lateexante.data, std.lv=T, ordered=c("q1_rev", "q2_rev", "q4_rev", "q5", "q7", "q8", "q10", "q11", "q26", "q27", "q29", "q30", "q9_rev", "q13", "q14", "q15_rev", "q16_rev", "q17_rev", "q18_rev", "q19_rev", "q20", "q21", "q22", "q23", "q25"))
reliability(cfa.exante.fit)


# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC

# Estimate number of latent classes
lateexantepoLCA.data <- read.table("choose4cyprus_exante_late_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateexantepoLCA.data)
poLCA_exante_LR <- data.frame(cbind( q1_rev_poLCA, q2_rev_poLCA, q4_rev_poLCA, q5_poLCA, q7_poLCA, q8_poLCA, q10_poLCA, q11_poLCA, q26_poLCA, q27_poLCA, q29_poLCA, q30_poLCA))
poLCA_exante_Cult <- data.frame(cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q20_poLCA, q21_poLCA, q22_poLCA, q23_poLCA, q25_poLCA))
detach(lateexantepoLCA.data)

# LR
f <- cbind(q1_rev_poLCA, q2_rev_poLCA, q4_rev_poLCA, q5_poLCA, q7_poLCA, q8_poLCA, q10_poLCA, q11_poLCA, q26_poLCA, q27_poLCA, q29_poLCA, q30_poLCA)~1
poLCA(f,poLCA_exante_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 12, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q9_rev_poLCA, q13_poLCA, q14_poLCA, q15_rev_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q20_poLCA, q21_poLCA, q22_poLCA, q23_poLCA, q25_poLCA)~1
poLCA(f,poLCA_exante_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 13, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(late_exante_LR.data, LCRC=T, nclass=9)
check.reliability (late_exante_Cult.data, LCRC=T, nclass=12)


###############################################################################################################################



###########
## Table 6b
###########


# Check quasi-inductive scales


# Mokken scaling analysis
lateqi.data <- read.table("choose4cyprus_qi_late.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateqi.data)
late_qi_LR.data <- data.frame(cbind( q1_rev, q4_rev, q6_rev, q7, q11, q26, q29, q30))
late_qi_Cult.data <- data.frame(cbind( q9_rev, q13, q14, q16_rev, q17_rev, q18_rev, q19_rev, q21, q23, q25))
detach(lateqi.data)
coefH(late_qi_LR.data)
m.late_qi_LR <- check.monotonicity(late_qi_LR.data, minsize = 100)
summary(m.late_qi_LR)
coefH(late_qi_Cult.data)
m.late_qi_Cult <- check.monotonicity(late_qi_Cult.data, minsize = 100)
summary(m.late_qi_Cult)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS)
cfa.qi <-   'LR =~ q1_rev + q4_rev + q6_rev + q7 + q11 + q26 + q29 + q30
Cult =~ q9_rev + q13 + q14 + q16_rev + q17_rev + q18_rev + q19_rev + q21 + q23 + q25'
cfa.qi.fit <- cfa(cfa.qi, data=lateqi.data, std.lv=T, ordered=c( "q1_rev", "q4_rev", "q6_rev", "q7",  "q11",  "q26", "q29", "q30", "q9_rev", "q13", "q14", "q16_rev", "q17_rev", "q18_rev", "q19_rev", "q21", "q23", "q25"))
reliability(cfa.qi.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC

# Estimate number of latent classes
lateqipoLCA.data <- read.table("choose4cyprus_qi_late_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateqipoLCA.data)
poLCA_qi_LR <- data.frame(cbind( q1_rev_poLCA, q4_rev_poLCA, q6_rev_poLCA, q7_poLCA, q11_poLCA, q26_poLCA, q29_poLCA, q30_poLCA))
poLCA_qi_Cult <- data.frame(cbind( q9_rev_poLCA, q13_poLCA, q14_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q21_poLCA, q23_poLCA, q25_poLCA))
detach(lateqipoLCA.data)

# LR
f <- cbind( q1_rev_poLCA, q4_rev_poLCA, q6_rev_poLCA, q7_poLCA, q11_poLCA, q26_poLCA, q29_poLCA, q30_poLCA)~1
poLCA(f,poLCA_qi_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 9, maxiter = 5000,nrep=5)
# Cult
f <- cbind( q9_rev_poLCA, q13_poLCA, q14_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_rev_poLCA, q21_poLCA, q23_poLCA, q25_poLCA)~1
poLCA(f,poLCA_qi_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 13, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 14, maxiter = 5000,nrep=5)

# Estimate reliability
check.reliability(late_qi_LR.data, LCRC=T, nclass=8)
check.reliability (late_qi_Cult.data, LCRC=T, nclass=13)


txtStop()  # Stop recording
