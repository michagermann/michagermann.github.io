
#    ########################################################################		#
#	   ########################################################################		#
#		  File:				    votulmeu_script.R                           							#
#		  Date:			  	  October 2014								                        			#
#		  Author:			    MG												                            		#
#		  Purpose:			  Dynamic Scale Validation Reloaded   			            		#
#		  Input file:		  Several     									                        		#         
#		  Log file:			  Rlog_Parteienavi.txt							                    		#
#		  Data output:	  None										                          		  	#
#		  Machine:		  	Preference Matcher server/Office laptop            				#
#		  R version:	    3.0.2/3.1.0 						                          				#
#		########################################################################		#
#		########################################################################		#



##################################################################################
## Install & load packages, set memory size, set working directory, start log file
##################################################################################

install.packages("mokken")
install.packages("poLCA")
install.packages("polycor")
install.packages("psych")
install.packages("GPArotation")
install.packages("nFactors")
install.packages("lavaan")
install.packages("semTools")
install.packages("TeachingDemos")

library(mokken)
library(poLCA)
library(polycor)
library(psych)
library(GPArotation)
library(nFactors)
library(lavaan)
library(semTools)
require(TeachingDemos)

memory.size(max=TRUE)

# Set directory
setwd(".../Replication files/votulmeu")

txtStart(file="Rlog_votulmeu.txt")  # Start recording to Rlog_votulmeu.txt



###########
## Table 2a
###########


# Check ex-ante scales


# Mokken scaling analysis
first3000exante.data <- read.table("votulmeu_exante_first3000.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(first3000exante.data)
first3000_exante_LR.data <- data.frame(cbind( q1_rev, q2, q3_rev, q4_rev, q5, q6_rev, q7, q21_rev))
first3000_exante_Cult.data <- data.frame(cbind(q12_rev, q16_rev, q17, q18, q19, q20_rev, q22, q26_rev, q28_rev, q29, q30_rev))
detach(first3000exante.data)
coefH(first3000_exante_LR.data)
m.first3000_exante_LR <- check.monotonicity(first3000_exante_LR.data, minsize = 100)
summary(m.first3000_exante_LR)
coefH(first3000_exante_Cult.data)
m.first3000_exante_Cult <- check.monotonicity(first3000_exante_Cult.data, minsize = 100)
summary(m.first3000_exante_Cult)


# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
cfa.exante <-   'LR =~ q1_rev + q2 + q3_rev + q4_rev + q5 + q6_rev + q7 + q21_rev
                Cult =~ q12_rev + q16_rev + q17 + q18 + q19 + q20_rev + q22 + q26_rev + q28_rev + q29 + q30_rev'
cfa.exante.fit <- cfa(cfa.exante, data=first3000exante.data, std.lv=T, ordered=c("q1_rev", "q2", "q3_rev", "q4_rev", "q5", "q6_rev", "q7", "q21_rev", "q12_rev", "q16_rev", "q17", "q18", "q19", "q20_rev", "q22", "q26_rev", "q28_rev", "q29", "q30_rev"))
reliability(cfa.exante.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
first3000exantepoLCA.data <- read.table("votulmeu_exante_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(first3000exantepoLCA.data)
poLCA_exante_LR <- data.frame(cbind( q1_rev_poLCA, q2_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q21_rev_poLCA))
poLCA_exante_Cult <- data.frame(cbind(q12_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q19_poLCA, q20_rev_poLCA, q22_poLCA, q26_rev_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA))
detach(first3000exantepoLCA.data)

# Estimate number of latent classes
# LR
f <- cbind(q1_rev_poLCA, q2_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q21_rev_poLCA)~1
poLCA(f,poLCA_exante_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q12_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q19_poLCA, q20_rev_poLCA, q22_poLCA, q26_rev_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA)~1
poLCA(f,poLCA_exante_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 7, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(first3000_exante_LR.data, LCRC=T, nclass=4)
check.reliability (first3000_exante_Cult.data, LCRC=T, nclass=6)


###############################################################################################################################



###########
## Table A2
###########


# Quasi-inductive search using AISP algorithm
emok.data <- read.table("votulmeu_emok.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Run AISP
aisp <- aisp(emok.data, search = "normal", lowerbound = .3)
coefH(emok.data[,aisp ==1])
coefH(emok.data[,aisp ==2])
coefH(emok.data[,aisp ==3])
coefH(emok.data[,aisp ==4])
coefH(emok.data[,aisp ==5])
coefH(emok.data[,aisp ==6])
coefH(emok.data[,aisp ==7])
coefH(emok.data[,aisp ==8])
coefH(emok.data[,aisp ==9])
coefH(emok.data[,aisp ==10])
coefH(emok.data[,aisp ==11])
coefH(emok.data[,aisp ==12])
coefH(emok.data[,aisp ==13])

# Monotonicity test of two main scales
attach(emok.data)
cmok.LR.aisp  <- data.frame(cbind( q1_rev, q2, q5, q6_rev, q7, q14, q17, q24))
cmok.Cult.aisp <- data.frame(cbind(q11_rev, q26_rev, q27, q28_rev, q29))
detach(emok.data)
coefH(cmok.LR.aisp)
m.cmok.LR.aisp <- check.monotonicity(cmok.LR.aisp, minsize = 100)
summary(m.cmok.LR.aisp)
coefH(cmok.Cult.aisp)
m.cmok.Cult.aisp <- check.monotonicity(cmok.Cult.aisp, minsize = 100)
summary(m.cmok.Cult.aisp)



# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
attach(emok.data)
cfa.aisp.data <- data.frame(cbind( q1_rev, q2, q5, q6_rev, q7, q14, q17, q24, q11_rev, q26_rev, q27, q28_rev, q29))
detach(emok.data)
cfa.aisp <-   'LR =~ q1_rev + q2 + q5 + q6_rev + q7 + q14 + q17 + q24
Cult =~ q11_rev + q26_rev + q27 + q28_rev + q29'
cfa.aisp.fit <- cfa(cfa.aisp, data=cfa.aisp.data, std.lv=T, ordered=c( "q1_rev", "q2", "q5", "q6_rev", "q7", "q14", "q17", "q24", "q11_rev", "q26_rev", "q27", "q28_rev", "q29"))
reliability(cfa.aisp.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
poLCA.aisp <- read.table("votulmeu_first3000_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(poLCA.aisp)
poLCA_aisp_LR <- data.frame(cbind( q1_rev_poLCA, q2_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q14_poLCA, q17_poLCA, q24_poLCA))
poLCA_aisp_Cult <- data.frame(cbind(q11_rev_poLCA, q26_rev_poLCA, q27_poLCA, q28_rev_poLCA, q29_poLCA))
detach(poLCA.aisp)

# Estimate number of latent classes
# LR
f <- cbind(q1_rev_poLCA, q2_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q14_poLCA, q17_poLCA, q24_poLCA)~1
poLCA(f,poLCA_aisp_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q11_rev_poLCA, q26_rev_poLCA, q27_poLCA, q28_rev_poLCA, q29_poLCA)~1
poLCA(f,poLCA_aisp_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_aisp_Cult,nclass = 5, maxiter = 5000,nrep=15)

# Estimate coefficients
check.reliability(cmok.LR.aisp, LCRC=T, nclass=4)
check.reliability (cmok.Cult.aisp, LCRC=T, nclass=4)


###############################################################################################################################



###########
## Table 2b
###########


# Quasi-inductive search using GA algorithm

# Run GA
ga <- aisp(emok.data, search = "ga", lowerbound = .3)
coefH(emok.data[,ga ==1])
coefH(emok.data[,ga ==2])
coefH(emok.data[,ga ==3])
coefH(emok.data[,ga ==4])
coefH(emok.data[,ga ==5])
coefH(emok.data[,ga ==6])
coefH(emok.data[,ga ==7])
coefH(emok.data[,ga ==8])
coefH(emok.data[,ga ==9])

# Monotonicity test of two resulting scales
attach(emok.data)
cmok.LR.ga  <- data.frame(cbind( q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q21_rev, q24))
cmok.Cult.ga <- data.frame(cbind( q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev))
detach(emok.data)
coefH(cmok.LR.ga)
m.cmok.LR.ga <- check.monotonicity(cmok.LR.ga, minsize = 100)
summary(m.cmok.LR.ga)
coefH(cmok.Cult.ga)
m.cmok.Cult.ga <- check.monotonicity(cmok.Cult.ga, minsize = 100)
summary(m.cmok.Cult.ga)

# q21_rev fails monotonicity test --> re-run test w/o item 21
attach(emok.data)
cmok.LR.ga  <- data.frame(cbind( q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24))
detach(emok.data)
coefH(cmok.LR.ga)
m.cmok.LR.ga <- check.monotonicity(cmok.LR.ga, minsize = 100)
summary(m.cmok.LR.ga)

# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS) 
attach(emok.data)
cfa.ga.data <- data.frame(cbind( q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev))
detach(emok.data)
cfa.ga <-   'LR =~ q1_rev + q3_rev + q4_rev + q5 + q6_rev + q7 + q14 + q24
Cult =~ q11_rev + q18 + q20_rev + q26_rev + q27 + q28_rev + q29 + q30_rev'
cfa.ga.fit <- cfa(cfa.ga, data=cfa.ga.data, std.lv=T, ordered=c( "q1_rev", "q3_rev", "q4_rev", "q5", "q6_rev", "q7", "q14", "q24", "q11_rev", "q18", "q20_rev", "q26_rev", "q27", "q28_rev", "q29", "q30_rev"))
reliability(cfa.ga.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC
attach(poLCA.aisp)
poLCA_ga_LR <- data.frame(cbind( q1_rev_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q14_poLCA, q24_poLCA))
poLCA_ga_Cult <- data.frame(cbind(q11_rev_poLCA, q18_poLCA, q20_rev_poLCA, q26_rev_poLCA, q27_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA))
detach(poLCA.aisp)

# Estimate number of latent classes
# LR
f <- cbind( q1_rev_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q14_poLCA, q24_poLCA)~1
poLCA(f,poLCA_ga_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_LR,nclass = 5, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q11_rev_poLCA, q18_poLCA, q20_rev_poLCA, q26_rev_poLCA, q27_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA)~1
poLCA(f,poLCA_ga_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_ga_Cult,nclass = 7, maxiter = 5000,nrep=5)

# Reliability coefficients
check.reliability(cmok.LR.ga, LCRC=T, nclass=4)
check.reliability (cmok.Cult.ga, LCRC=T, nclass=6)


###############################################################################################################################



# Ambiguity check (AISP solution)
# Show that there are no cross-loadings
lr1 <- subset(emok.data, select=c(q1_rev, q2, q5, q6_rev, q7, q14, q17, q24, q11_rev))
lr2 <- subset(emok.data, select=c(q1_rev, q2, q5, q6_rev, q7, q14, q17, q24, q26_rev))
lr3 <- subset(emok.data, select=c(q1_rev, q2, q5, q6_rev, q7, q14, q17, q24, q27))
lr4 <- subset(emok.data, select=c(q1_rev, q2, q5, q6_rev, q7, q14, q17, q24, q28_rev))
lr5 <- subset(emok.data, select=c(q1_rev, q2, q5, q6_rev, q7, q14, q17, q24, q29))
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)

cult1 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q1_rev))
cult2 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q2))
cult3 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q5))
cult4 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q6_rev))
cult5 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q7))
cult6 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q14))
cult7 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q17))
cult8 <- subset(emok.data, select=c(q11_rev, q26_rev, q27, q28_rev, q29, q24))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)


# Ambiguity check (GA solution)
# Show that there are no cross-loadings

lr1 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q11_rev))
lr2 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q18))
lr3 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q20_rev))
lr4 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q26_rev))
lr5 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q27))
lr6 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q28_rev))
lr7 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q29))
lr8 <- subset(emok.data, select=c(q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24, q30_rev))
coefH(lr1)
coefH(lr2)
coefH(lr3)
coefH(lr4)
coefH(lr5)
coefH(lr6)
coefH(lr7)
coefH(lr8)

cult1 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q1_rev))
cult2 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q3_rev))
cult3 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q4_rev))
cult4 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q5))
cult5 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q6_rev))
cult6 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q7))
cult7 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q14))
cult8 <- subset(emok.data, select=c(q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev, q24))
coefH(cult1)
coefH(cult2)
coefH(cult3)
coefH(cult4)
coefH(cult5)
coefH(cult6)
coefH(cult7)
coefH(cult8)



###############################################################################################################################



# Confirm 2-D structure using EFA (polychoric principal axis)
efa.data <- read.table("votulmeu_efa.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Determine number of factors
pa.poly <- fa.poly(x=efa.data, fm="pa", nfactors=2, rotate="promax")
pa.poly$fa$values
plot(pa.poly$fa$values,type="b", main = "Scree plot",ylab="Eigenvalues of factors",ylim=c(0,max(pa.poly$fa$values)) ,xlab="Factor Number",pch=4,col="blue")

# Two-factor solution, promax-rotated (to be preferred if there are items with strong crossloadings, see Thompson 2004)
print(pa.poly$fa, digits=3, cut=.3)


#########################################################################################################



###########
## Table 5a
###########


# Check ex-ante scales

# Mokken scaling analysis
lateexante.data <- read.table("votulmeu_exante_late.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateexante.data)
late_exante_LR.data <- data.frame(cbind( q1_rev, q2, q3_rev, q4_rev, q5, q6_rev, q7, q21_rev))
late_exante_Cult.data <- data.frame(cbind(q12_rev, q16_rev, q17, q18, q19, q20_rev, q22, q26_rev, q28_rev, q29, q30_rev))
detach(lateexante.data)
coefH(late_exante_LR.data)
m.late_exante_LR <- check.monotonicity(late_exante_LR.data, minsize = 100)
summary(m.late_exante_LR)
coefH(late_exante_Cult.data)
m.late_exante_Cult <- check.monotonicity(late_exante_Cult.data, minsize = 100)
summary(m.late_exante_Cult)

# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS)
cfa.exante <-   'LR =~ q1_rev + q2 + q3_rev + q4_rev + q5 + q6_rev + q7 + q21_rev
Cult =~ q12_rev + q16_rev + q17 + q18 + q19 + q20_rev + q22 + q26_rev + q28_rev + q29 + q30_rev'
cfa.exante.fit <- cfa(cfa.exante, data=lateexante.data, std.lv=T, ordered=c("q1_rev", "q2", "q3_rev", "q4_rev", "q5", "q6_rev", "q7", "q21_rev", "q12_rev", "q16_rev", "q17", "q18", "q19", "q20_rev", "q22", "q26_rev", "q28_rev", "q29", "q30_rev"))
reliability(cfa.exante.fit)


# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC

# Estimate number of latent classes
lateexantepoLCA.data <- read.table("votulmeu_exante_late_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateexantepoLCA.data)
poLCA_exante_LR <- data.frame(cbind( q1_rev_poLCA, q2_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q21_rev_poLCA))
poLCA_exante_Cult <- data.frame(cbind(q12_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q19_poLCA, q20_rev_poLCA, q22_poLCA, q26_rev_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA))
detach(lateexantepoLCA.data)

# LR
f <- cbind(q1_rev_poLCA, q2_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q21_rev_poLCA)~1
poLCA(f,poLCA_exante_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_LR,nclass = 11, maxiter = 5000,nrep=5)
# Cult
f <- cbind(q12_rev_poLCA, q16_rev_poLCA, q17_poLCA, q18_poLCA, q19_poLCA, q20_rev_poLCA, q22_poLCA, q26_rev_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA)~1
poLCA(f,poLCA_exante_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_exante_Cult,nclass = 12, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(late_exante_LR.data, LCRC=T, nclass=10)
check.reliability (late_exante_Cult.data, LCRC=T, nclass=11)


###############################################################################################################################



###########
## Table 5b
###########


# Check quasi-inductive scales


# Mokken scaling analysis
lateqi.data <- read.table("votulmeu_qi_late.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateqi.data)
late_qi_LR.data <- data.frame(cbind( q1_rev, q3_rev, q4_rev, q5, q6_rev, q7, q14, q24))
late_qi_Cult.data <- data.frame(cbind( q11_rev, q18, q20_rev, q26_rev, q27, q28_rev, q29, q30_rev))
detach(lateqi.data)
coefH(late_qi_LR.data)
m.late_qi_LR <- check.monotonicity(late_qi_LR.data, minsize = 100)
summary(m.late_qi_LR)
coefH(late_qi_Cult.data)
m.late_qi_Cult <- check.monotonicity(late_qi_Cult.data, minsize = 100)
summary(m.late_qi_Cult)

# Reliability estimates

# Ordinal alpha & Ordinal omega 
# CFA for omega estimate is based on polychoric correlation matrix
# and fitted using WLSMV (robust DWLS)
cfa.qi <-   'LR =~ q1_rev + q3_rev + q4_rev + q5 + q6_rev + q7 + q14 + q24
Cult =~ q11_rev + q18 + q20_rev + q26_rev + q27 + q28_rev + q29 + q30_rev'
cfa.qi.fit <- cfa(cfa.qi, data=lateqi.data, std.lv=T, ordered=c( "q1_rev", "q3_rev", "q4_rev" , "q5", "q6_rev", "q7", "q14", "q24", "q11_rev", "q18", "q20_rev", "q26_rev", "q27", "q28_rev", "q29", "q30_rev"))
reliability(cfa.qi.fit)

# Alpha and LCRC
# For the LCRC we first need to determine the number of latent classes
# For this we base on the BIC

# Estimate number of latent classes
lateqipoLCA.data <- read.table("votulmeu_qi_late_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
attach(lateqipoLCA.data)
poLCA_qi_LR <- data.frame(cbind( q1_rev_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q14_poLCA, q24_poLCA))
poLCA_qi_Cult <- data.frame(cbind( q11_rev_poLCA, q18_poLCA, q20_rev_poLCA, q26_rev_poLCA, q27_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA))
detach(lateqipoLCA.data)

# LR
f <- cbind( q1_rev_poLCA, q3_rev_poLCA, q4_rev_poLCA, q5_poLCA, q6_rev_poLCA, q7_poLCA, q14_poLCA, q24_poLCA)~1
poLCA(f,poLCA_qi_LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_LR,nclass = 11, maxiter = 5000,nrep=5)
# Cult
f <- cbind( q11_rev_poLCA, q18_poLCA, q20_rev_poLCA, q26_rev_poLCA, q27_poLCA, q28_rev_poLCA, q29_poLCA, q30_rev_poLCA)~1
poLCA(f,poLCA_qi_Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA_qi_Cult,nclass = 12, maxiter = 5000,nrep=5)

# Estimate coefficients
check.reliability(late_qi_LR.data, LCRC=T, nclass=10)
check.reliability (late_qi_Cult.data, LCRC=T, nclass=11)


txtStop()  # Stop recording

